(function(){
const el=id=>document.getElementById(id),events=[['','无特殊条件'],['haitei','海底摸月'],['houtei','河底捞鱼'],['rinshan','岭上开花'],['chankan','抢杠'],['tenhou','天和'],['chiihou','地和']];
el('conditionbuttons').innerHTML='<p class="hint">以下条件无法只凭最终手牌判断，请按实际对局选择。其他标准牌型役由手牌自动识别。</p><div class="tabs">'+events.map(([v,n])=>`<button type="button" data-autoevent="${v}">${n}</button>`).join('')+'</div>';
window.refreshAutoConditions=()=>document.querySelectorAll('[data-autoevent]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.autoevent===el('event').value));
document.querySelectorAll('[data-autoevent]').forEach(b=>b.onclick=()=>{const v=b.dataset.autoevent;el('event').value=v;if(['haitei','rinshan','tenhou','chiihou'].includes(v))el('method').value='tsumo';if(['houtei','chankan'].includes(v))el('method').value='ron';if(['tenhou','chiihou'].includes(v)){el('riichi').value=0;el('ippatsu').checked=false;}if(v==='rinshan')el('ippatsu').checked=false;dirty();refreshAutoConditions();});
el('event').addEventListener('change',refreshAutoConditions);refreshAutoConditions();
})();
